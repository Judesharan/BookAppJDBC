package test.com.revature.bookapp.util;

import java.sql.Connection;

import com.revature.bookapp.util.ConnectionUtil;
 
public class TestConnectionUtil {
 
    public static void main(String[] args) throws Exception {
 
        Connection connection = ConnectionUtil.getConnection();
        System.out.println(connection);
 
    }
 
}

