package test.com.revature.bookapp.model;

import java.time.LocalDate;

import com.revature.bookapp.model.BookSales;

public class TestBookSales {
	public static void main(String[] args) {
		BookSales bookSales1 = new BookSales();
		
		bookSales1.setSalesID(1001);
		bookSales1.setUserID(101);
		bookSales1.setIsbn(9788700631625l);
		bookSales1.setQuantity(3);
		bookSales1.setPrice(250.00);
		bookSales1.setTotalAmount(bookSales1.getPrice() * bookSales1.getQuantity());
		bookSales1.setOrderDate(LocalDate.parse("2017-06-06"));
		bookSales1.setStatus("Shipped");
		
		System.out.println("Sales ID = " + bookSales1.getSalesID());
		System.out.println("User ID = " + bookSales1.getUserID());
		System.out.println("ISBN = " + bookSales1.getIsbn());
		System.out.println("Quantity = " + bookSales1.getQuantity());
		System.out.println("Price = " + bookSales1.getPrice());
		System.out.println("Total Amount = " + bookSales1.getTotalAmount());
		System.out.println("Order Date = " + bookSales1.getOrderDate());
		System.out.println("Status = " + bookSales1.getStatus());
	}
}
