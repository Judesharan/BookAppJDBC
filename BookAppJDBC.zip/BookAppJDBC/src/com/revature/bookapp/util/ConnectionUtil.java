package com.revature.bookapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class ConnectionUtil {
 
    public static Connection getConnection() {
         
        Connection connection  = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
         
             String url = "jdbc:mysql://localhost:3306/bookdb?useSSL=false";
             connection = DriverManager.getConnection(url,"root", "root");
         
        } catch (Exception e) {         
            e.printStackTrace();
        }
        return connection;
    }
    
    public static void close(Connection conn, PreparedStatement pst, ResultSet rs) {

		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {

		}

	}
}