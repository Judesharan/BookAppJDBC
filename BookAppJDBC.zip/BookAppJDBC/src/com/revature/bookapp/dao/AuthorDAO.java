package com.revature.bookapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.revature.bookapp.model.Book;
import com.revature.bookapp.util.ConnectionUtil;

public class AuthorDAO {

	/* Author can create a book */
	
	public void insertBook(Book book) throws Exception {
	 
		// 1. Get the connection
		Connection conn = ConnectionUtil.getConnection();

		// 2. Query
		String sql = "insert into book (isbn , title, author , publishDate ,content , price , status) values (?,?,?,?,?,?,?)";

		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setLong(1, book.getIsbn());
		pst.setString(2, book.getTitle());
		pst.setString(3, book.getAuthor());
		pst.setDate(4, Date.valueOf(book.getPublishDate()));
		pst.setString(5, book.getContent());
		pst.setDouble(6, book.getPrice());
		pst.setString(7, book.getStatus());

		// 4. Query execute
		int rows = pst.executeUpdate();
		System.out.println("No of rows inserted: " + rows);

		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, null);
	}

	/* Author can upload the contents of book */
	
	public void updateContent(Book book) throws Exception {
		
		// 1. Get the connection
		Connection conn = ConnectionUtil.getConnection();

		// 2. Query
		String sql = "update book set `content`=? WHERE `isbn`=?";
		
		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, book.getContent());
		pst.setLong(2, book.getIsbn());
		
		// 4. Query execute
		int row = pst.executeUpdate();
		System.out.println(row + " book content updated.");
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, null);
	}

	/* Author can view the book and contents */
	
	public void viewBook(Book book) throws Exception {
		
		// 1. Get the connection
		Connection conn = ConnectionUtil.getConnection();

		// 2. Query
		String sql = "select title,content from book where (isbn = ?)";
		
		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setLong(1, book.getIsbn());
		
		// 4. Query execute
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			String title = rs.getString("title");
			String content = rs.getString("content");
			System.out.println("Title:" + title);
			System.out.println("Content:" + content);
			System.out.println();
		}
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, rs);
	}

	/* Author can delete the book */
	
	public void deleteBook(Book book) throws Exception {
		
		// 1. Get the connection
		Connection conn = ConnectionUtil.getConnection();

		// 2. Query
		String sql = "delete from book where isbn = ?";
		
		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setLong(1, book.getIsbn());
		
		// 4. Query execute
		int row = pst.executeUpdate();
		System.out.println(row + " book deleted.");
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, null);
	}

	/* Author can view all his books */
	
	public void viewAllBooks(Book book) throws Exception {
		
		// Step 1:Get the connection
		Connection conn = ConnectionUtil.getConnection();

		// Step 2: Query
		String sql = "select title,content from book where author = ?";
		
		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, book.getAuthor());
		
		// 4. Query execute
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			String title = rs.getString("title");
			String content = rs.getString("content");
			System.out.println("Title:" + title);
			System.out.println("Content:" + content);
			System.out.println();
		}
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, rs);
	}

}
