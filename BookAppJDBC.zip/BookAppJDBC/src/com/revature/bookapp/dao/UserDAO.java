package com.revature.bookapp.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import com.revature.bookapp.model.User;
import com.revature.bookapp.util.ConnectionUtil;

public class UserDAO {
	
	/* New User Can Register */
	
	public void insertUser(User user) throws Exception {
		 
        // 1. Get the connection
        Connection conn = ConnectionUtil.getConnection();
 
        // 2. Query
        String sql = "insert into book (id , name, username , password ,mobile_no , email_ID , active, role_ID) values (?,?,?,?,?,?,?,?)";
 
        // 3. Set the input
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, user.getId());
        pst.setString(2, user.getName());
        pst.setString(3, user.getUserName());
        pst.setString(4, user.getPassword());
        pst.setLong(5, user.getMobileNumber());
        pst.setString(6, user.getEmailID());
        pst.setString(7, user.getActive());
        pst.setInt(8, user.getRoleId());
 
        // 4. Query execute
        int rows = pst.executeUpdate();
        System.out.println("No of rows inserted: " + rows);
        
        // 5. Close DB resources
    	ConnectionUtil.close(conn, pst, null);    	
    }
	
	/* User must be able to Login */
	public void loginUser(User user) throws Exception {
		
		// 1. Get the connection
        Connection conn = ConnectionUtil.getConnection();
		
        // 2. Query
        String query = "update user set active = 'A' where (userName= ?) and (password = ?)";
		
        // 3. Set the input
        PreparedStatement pst = conn.prepareStatement(query);
		pst.setString(1, user.getUserName());
		pst.setString(2, user.getPassword());
		
		// 4. Query execute
        int rows = pst.executeUpdate();
        System.out.println("No of rows inserted: " + rows);
		System.out.println("Login Sucess");
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, null);
	}
	
	/* User must be able to Reset Password */
	public void updatePassword(User user, String newPassword) throws Exception {
		
		// 1. Get the connection
        Connection conn = ConnectionUtil.getConnection();
		
        // 2. Query
		String query = "update user set password = ? where ((username = ?) and (active = 'A')) and password=?";
		
		// 3. Set the input
		PreparedStatement pst = conn.prepareStatement(query);
		pst.setString(1, newPassword);
		pst.setString(2, user.getUserName());
		pst.setString(3, user.getPassword());
		
		// 4. Query execute
		int rows = pst.executeUpdate();
		if (rows == 1) {
			System.out.println("No of rows inserted: " + rows);
			System.out.println("Password Reset Sucess");
		} else if (rows == 0) {
			System.out.println("No of rows inserted: " + rows);
			System.out.println("Please Login to reset");
		} else {
			System.out.println("No of rows inserted: " + rows);
			System.out.println("Error Reset");
		}
		
		// 5. Close DB resources
		ConnectionUtil.close(conn, pst, null);
	}
}
